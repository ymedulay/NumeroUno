<?php include 'nav.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us - NumeroUno</title>
    <link href="https://fonts.googleapis.com/css?family=Inter" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/styles.css">
    <script src="https://unpkg.com/@phosphor-icons/web@2.1.1"></script>
</head>

<body id="contact-us-page">
    <h1><b> Get in Touch with Us! </b></h1>
    <div class="contact-map-wrapper">
        <div class="contact-container">
            <h2>Send a Message</h2>
            <p>Got a question or want to leave a review? Leave us a message below.</p>
            <form>
                <label for="name">Name</label>
                <input type="text" id="name" placeholder="e.g., John Dela Cruz" required>

                <label for="contact">Contact No.</label>
                <input type="text" id="contact" placeholder="e.g., 09123456789" required>

                <label for="email">Email Address</label>
                <input type="email" id="email" placeholder="e.g., example@email.com" required>

                <label for="message">Message</label>
                <textarea id="message" rows="4" placeholder="Type your message here..." required></textarea>

                <div class="checkbox-container">
                    <input type="checkbox" id="reviewCheck">
                    <label for="reviewCheck">Check this box if you're leaving a review.</label>
                </div>

                <button class="btn" type="submit">Submit</button>
            </form>
        </div>

        <div class="barangay-container">
            <h2>Call Us</h2>
            <p><i class="ph ph-phone"></i> 091234567</p>
            <h2>Email</h2>
            <p><i class="ph ph-envelope"></i> brgyconcepcionuno@yahoo.com</p>
            <h2>Visit Us</h2>
            <p><i class="ph ph-map-pin"></i> Concepcion Uno Barangay Hall, Molave St, Marikina, 1800 Metro Manila</p>
            <iframe class="embed-map" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3860.0493625715003!2d121.10447520000001!3d14.6531394!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3397b9bed8201ba1%3A0x113c8c2114eb3b6d!2sConcepcion%20Uno%20Barangay%20Hall%20(Marikina)!5e0!3m2!1sen!2sph!4v1739789587001!5m2!1sen!2sph" allowfullscreen="" loading="lazy"></iframe>

            <h2>Office Hours</h2>
            <ul>
                <li>Monday - Friday: 8:00 AM - 12:00 PM, 1:00 PM - 5:00 PM</li>
                <li>Saturday - Sunday: CLOSED</li>
            </ul>
        </div>
    </div>

    <script>
        function toggleDropdown(id) {
            const dropdown = document.getElementById(id);
            dropdown.classList.toggle("show");
        }

        document.addEventListener("click", function(e) {
            if (!e.target.matches('.ph')) {
                document.querySelectorAll('.dropdown-menu').forEach(menu => menu.classList.remove('show'));
            }
        });
    </script>
</body>

</html>