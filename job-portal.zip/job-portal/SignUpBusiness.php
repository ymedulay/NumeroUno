<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Business Sign-Up</title>
    <link href='https://fonts.googleapis.com/css?family=Inter' rel='stylesheet'>
    <link rel="stylesheet" href="assets/css/login-signin.css">
</head>

<body id="login-signin-page">
    <div class="container">
        <div class="signup-card">
            <div class="top-section">
                <img src="assets/images/NumeroUnoLogo.png" alt="Numero Uno Logo">
            </div>

            <form action="process_signup.php" method="POST">
                <h2 class="form-title">Create Business Account</h2>

                <div class="input-group">
                    <label for="business-name">BUSINESS NAME</label>
                    <input type="text" id="business-name" name="business_name" placeholder="Enter your business name" required>
                </div>

                <div class="input-group">
                    <label for="business-email">BUSINESS EMAIL ADDRESS</label>
                    <input type="email" id="business-email" name="business_email" placeholder="Enter your business email" required>
                </div>

                <div class="input-group">
                    <label for="password">PASSWORD</label>
                    <input type="password" id="password" name="password" placeholder="Create a password" required>
                </div>

                <button type="submit" class="submit-btn">CREATE ACCOUNT</button>

                <div class="separator">
                    <hr>
                    <span>or</span>
                    <hr>
                </div>

                <div class="social-signin-container">
                    <button type="button" class="social-signin google">
                        <img src="assets/images/GoogleLogo.png" alt="Google logo"> Continue with Google
                    </button>
                    <button type="button" class="social-signin facebook">
                        <img src="assets/images/FacebookLogo.png" alt="Facebook logo"> Continue with Facebook
                    </button>
                </div>

                <p class="login-link">Already have a business account? <a href="LoginPage.php">LOG IN</a></p>
            </form>
        </div>
    </div>
</body>

</html>